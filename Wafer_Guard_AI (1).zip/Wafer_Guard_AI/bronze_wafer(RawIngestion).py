# Databricks notebook source
# MAGIC %md
# MAGIC What is a wafer?
# MAGIC A wafer is a thin, round slice of semiconductor material, usually silicon, used to manufacture electronic chips.
# MAGIC thin plate on which thousands of tiny electronic chips are manufactured.

# COMMAND ----------

# MAGIC %md
# MAGIC Reading Wafer Dataset

# COMMAND ----------

from pyspark.sql import functions as F

BRONZE_TABLE = "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"

bronze = spark.table(BRONZE_TABLE)

# COMMAND ----------

from pyspark.sql import functions as F

# Dataset paths
DATA_PATH = "/Volumes/wafer_guard_ai/bronze_wafer/waferguard_files"

TRAIN_FILE = f"{DATA_PATH}/Wafer_TRAIN.ts"
TEST_FILE = f"{DATA_PATH}/Wafer_TEST.ts"

# Read the complete files as raw text
train_raw = (
    spark.read.text(TRAIN_FILE)
    .withColumnRenamed("value", "raw_line")
    .withColumn("split_name", F.lit("train"))
)

test_raw = (
    spark.read.text(TEST_FILE)
    .withColumnRenamed("value", "raw_line")
    .withColumn("split_name", F.lit("test"))
)

# Combine without losing the original split
bronze_raw = train_raw.unionByName(test_raw)

print("Training raw lines:", train_raw.count())
print("Testing raw lines:", test_raw.count())

display(bronze_raw.limit(20))

# COMMAND ----------

# MAGIC %md
# MAGIC Creating the bronze delta table

# COMMAND ----------

BRONZE_TABLE = (
    "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"
)

bronze_final = bronze_raw.withColumn(
    "ingested_at", F.current_timestamp()
)

(
    bronze_final.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(BRONZE_TABLE)
)

print("Bronze table created:", BRONZE_TABLE)

display(spark.table(BRONZE_TABLE).limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC Inspect the .ts format before parsing

# COMMAND ----------

# Display the metadata and first data records
display(
    spark.table(BRONZE_TABLE)
    .filter(
        F.col("raw_line").startswith("@")
        | (
            F.length(F.trim("raw_line")) > 0
        )
    )
    .select("split_name", "raw_line")
    .limit(35)
)

# COMMAND ----------

# MAGIC %md
# MAGIC checking class labels and row counts

# COMMAND ----------

from pyspark.sql import functions as F

# Step 1: Load the Bronze table
BRONZE_TABLE = "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"
bronze = spark.table(BRONZE_TABLE)

# Step 2: Display metadata lines
display(
    bronze.filter(
        F.lower(F.trim(F.col("raw_line"))).startswith("@")
    ).select("split_name", "raw_line")
)

# Step 3: Exclude metadata and empty lines
data_rows = bronze.filter(
    F.col("raw_line").isNotNull()
    & (F.length(F.trim(F.col("raw_line"))) > 0)
    & (~F.lower(F.trim(F.col("raw_line"))).startswith("@"))
    & (~F.trim(F.col("raw_line")).startswith("#"))
)

# Step 4: Count records for train and test
display(
    data_rows.groupBy("split_name")
    .agg(F.count("*").alias("raw_record_count"))
)

# COMMAND ----------

# MAGIC %md
# MAGIC Inspects the raw data

# COMMAND ----------

from pyspark.sql import functions as F

BRONZE_TABLE = (
    "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"
)

bronze = spark.table(BRONZE_TABLE)

# Show the dataset metadata
display(
    bronze.filter(
        F.lower(F.trim("raw_line")).startswith("@")
    ).select("split_name", "raw_line")
)

# Inspect the first 10 non-metadata records
data_rows = bronze.filter(
    (F.length(F.trim("raw_line")) > 0)
    & (~F.lower(F.trim("raw_line")).startswith("@"))
)

display(
    data_rows.select(
        "split_name",
        F.substring("raw_line", 1, 120).alias("line_start"),
        F.expr("right(raw_line, 120)").alias("line_end"),
        F.size(F.split("raw_line", ",")).alias("comma_fields"),
        F.size(F.split("raw_line", ":")).alias("colon_fields")
    ).limit(10)
)

print("Total raw records:", data_rows.count())

# COMMAND ----------

# MAGIC %md
# MAGIC bronze validation

# COMMAND ----------

from pyspark.sql import functions as F

BRONZE_TABLE = "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"

bronze = spark.table(BRONZE_TABLE)

data_rows = bronze.filter(
    (F.length(F.trim("raw_line")) > 0) &
    (~F.lower(F.trim("raw_line")).startswith("@")) &
    (~F.trim("raw_line").startswith("#"))
)

display(
    data_rows.groupBy("split_name")
    .agg(F.count("*").alias("raw_record_count"))
)

print("Total raw lines:", bronze.count())
print("Non-metadata records:", data_rows.count())

display(data_rows.select("split_name", "raw_line").limit(5))

# COMMAND ----------

# MAGIC %md
# MAGIC checks row counts, train/test separation, metadata, and empty records without modifying or deleting the Bronze table.

# COMMAND ----------

from pyspark.sql import functions as F

BRONZE_TABLE = (
    "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"
)

bronze = spark.table(BRONZE_TABLE)

# 1. Total raw records
print("Total Bronze rows:", bronze.count())

# 2. Count records for train and test
display(
    bronze.groupBy("split_name")
    .agg(
        F.count("*").alias("total_lines"),
        F.sum(
            F.when(
                F.length(F.trim("raw_line")) > 0, 1
            ).otherwise(0)
        ).alias("non_empty_lines"),
        F.sum(
            F.when(
                F.lower(F.trim("raw_line")).startswith("@"), 1
            ).otherwise(0)
        ).alias("metadata_lines")
    )
)

# 3. Check empty or null raw records
display(
    bronze.filter(
        F.col("raw_line").isNull()
        | (F.length(F.trim("raw_line")) == 0)
    ).groupBy("split_name").count()
)

# 4. Inspect actual data rows, excluding metadata
data_rows = bronze.filter(
    F.col("raw_line").isNotNull()
    & (F.length(F.trim("raw_line")) > 0)
    & (~F.lower(F.trim("raw_line")).startswith("@"))
)

display(
    data_rows.select("split_name", "raw_line")
    .limit(10)
)

# 5. Check class-label and time-series format manually
print("Non-empty data rows:", data_rows.count())