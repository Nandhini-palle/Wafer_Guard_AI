# Databricks notebook source
# MAGIC %md
# MAGIC Reading silver layer

# COMMAND ----------

SILVER_TABLE = "Wafer_Guard_AI.silver_wafer.wafer_timeseries_clean"

silver_df = spark.table(SILVER_TABLE)

print("Silver records:", silver_df.count())
silver_df.printSchema()

display(silver_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC checks data quality before gold

# COMMAND ----------

from pyspark.sql import functions as F

print("Total rows:", silver_df.count())
print("Duplicate rows:", silver_df.count() - silver_df.dropDuplicates().count())

display(
    silver_df.select([
        F.sum(F.col(c).isNull().cast("int")).alias(c)
        for c in silver_df.columns
    ])
)

# COMMAND ----------

# MAGIC %md
# MAGIC create a gold summary table

# COMMAND ----------

GOLD_TABLE = "Wafer_Guard_AI.gold_wafer.wafer_summary"

gold_df = (
    silver_df
    .groupBy("split_name")
    .agg(
        F.count("*").alias("total_records"),
        F.round(F.avg("measurement_count"), 2)
         .alias("avg_measurement_count"),
        F.round(F.min("measurement_count"), 2)
         .alias("min_measurement_count"),
        F.round(F.max("measurement_count"), 2)
         .alias("max_measurement_count")
    )
)

(
    gold_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(GOLD_TABLE)
)

print("Gold summary table created:", GOLD_TABLE)
display(spark.table(GOLD_TABLE))

# COMMAND ----------

# MAGIC %md
# MAGIC validate Gold table

# COMMAND ----------

from pyspark.sql import functions as F

GOLD_TABLE = "Wafer_Guard_AI.gold_wafer.wafer_summary"
SILVER_TABLE = "Wafer_Guard_AI.silver_wafer.wafer_timeseries_clean"

gold_df = spark.table(GOLD_TABLE)
silver_df = spark.table(SILVER_TABLE)

print("GOLD LAYER VALIDATION")
print("-" * 40)
print("Silver row count:", silver_df.count())
print("Gold row count:", gold_df.count())
print("Gold columns:", gold_df.columns)

gold_df.printSchema()
display(gold_df)

# COMMAND ----------

# MAGIC %md
# MAGIC check missing values and dublicates

# COMMAND ----------

# Missing values in Silver
null_checks = [
    F.sum(F.col(c).isNull().cast("long")).alias(c)
    for c in silver_df.columns
]

print("NULL VALUE CHECK")
display(silver_df.agg(*null_checks))

# Exact duplicate rows
silver_count = silver_df.count()
unique_count = silver_df.dropDuplicates().count()

print("Total Silver rows:", silver_count)
print("Exact duplicate rows:", silver_count - unique_count)

# Check whether Gold contains nulls
display(
    gold_df.agg(*[
        F.sum(F.col(c).isNull().cast("long")).alias(c)
        for c in gold_df.columns
    ])
)

# COMMAND ----------

# MAGIC %md
# MAGIC compare training and testing data

# COMMAND ----------

# Identify numeric columns automatically
numeric_types = {
    "byte", "short", "integer", "long",
    "float", "double", "decimal"
}

numeric_cols = [
    field.name
    for field in silver_df.schema.fields
    if field.dataType.typeName() in numeric_types
    and field.name != "split_name"
]

if not numeric_cols:
    print("No numeric columns found. Check the Silver schema.")
else:
    expressions = [F.count("*").alias("total_rows")]

    for c in numeric_cols:
        expressions.extend([
            F.round(F.avg(F.col(c)), 2).alias(f"{c}_avg"),
            F.round(F.stddev(F.col(c)), 2).alias(f"{c}_stddev"),
            F.round(F.min(F.col(c)), 2).alias(f"{c}_min"),
            F.round(F.max(F.col(c)), 2).alias(f"{c}_max")
        ])

    comparison_df = (
        silver_df
        .groupBy("split_name")
        .agg(*expressions)
    )

    display(comparison_df)

# COMMAND ----------

# MAGIC %md
# MAGIC save comparison metrics in Gold

# COMMAND ----------

COMPARISON_TABLE = (
    "Wafer_Guard_AI.gold_wafer.train_test_comparison"
)

(
    comparison_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(COMPARISON_TABLE)
)

print("Comparison table saved:", COMPARISON_TABLE)
display(spark.table(COMPARISON_TABLE))

# COMMAND ----------

# MAGIC %md
# MAGIC validate train/test split counts

# COMMAND ----------

split_validation = (
    silver_df
    .groupBy("split_name")
    .agg(
        F.count("*").alias("total_rows"),
        F.countDistinct("raw_line").alias("distinct_raw_lines")
    )
)

display(split_validation)

# COMMAND ----------

# MAGIC %md
# MAGIC compare numerical distribution visually

# COMMAND ----------

import matplotlib.pyplot as plt

if numeric_cols:
    selected_col = numeric_cols[0]

    plot_df = (
        silver_df
        .groupBy("split_name")
        .agg(
            F.round(F.avg(F.col(selected_col)), 2)
             .alias("average_value")
        )
        .orderBy("split_name")
        .toPandas()
    )

    plt.figure(figsize=(7, 4))
    plt.bar(plot_df["split_name"], plot_df["average_value"])
    plt.title(f"Train vs Test: Average {selected_col}")
    plt.xlabel("Dataset Split")
    plt.ylabel(f"Average {selected_col}")
    plt.tight_layout()
    plt.show()
else:
    print("No numeric columns available for plotting.")