# Databricks notebook source
# MAGIC %md
# MAGIC Reading bronze layer in silver notebook

# COMMAND ----------

from pyspark.sql import functions as F

# Existing Bronze table
BRONZE_TABLE = (
    "Wafer_Guard_AI.bronze_wafer.bronze_wafer_raw"
)

# Read Bronze data
bronze_df = spark.table(BRONZE_TABLE)

print("Bronze table loaded successfully")
print("Total Bronze rows:", bronze_df.count())

# Check the schema
bronze_df.printSchema()

# Display the first 10 raw records
display(bronze_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC Inspect and filter raw records

# COMMAND ----------

data_rows = bronze_df.filter(
    F.col("raw_line").isNotNull()
    & (F.length(F.trim("raw_line")) > 0)
    & (~F.lower(F.trim("raw_line")).startswith("@"))
    & (~F.trim("raw_line").startswith("#"))
)

print("Non-metadata rows:", data_rows.count())

display(
    data_rows.select(
        "split_name",
        "raw_line",
        F.size(F.split("raw_line", ":")).alias("colon_parts"),
        F.size(
            F.split(
                F.element_at(F.split("raw_line", ":"), 1),
                ","
            )
        ).alias("first_part_values")
    ).limit(10)
)

# COMMAND ----------

# MAGIC %md
# MAGIC
# MAGIC Parse the time-series values and class label

# COMMAND ----------

parsed_df = (
    data_rows
    .withColumn(
        "parts",
        F.split(F.trim("raw_line"), ":")
    )
    .withColumn(
        "class_label",
        F.trim(F.element_at("parts", -1))
    )
    .withColumn(
        "measurement_text",
        F.trim(F.element_at("parts", 1))
    )
)

silver_df = (
    parsed_df
    .withColumn(
        "measurements",
        F.expr("""
            transform(
                split(measurement_text, ','),
                x -> round(try_cast(trim(x) AS DOUBLE), 2)
            )
        """)
    )
    .withColumn(
        "measurement_count",
        F.size("measurements")
    )
    .withColumn(
        "processed_at",
        F.current_timestamp()
    )
    .select(
        "split_name",
        "class_label",
        "measurements",
        "measurement_count",
        "raw_line",
        "processed_at"
    )
)

display(silver_df.limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC Validate silver data

# COMMAND ----------

invalid_condition = (
    F.col("class_label").isNull()
    | (F.trim(F.col("class_label")) == "")
    | (F.col("measurement_count") == 0)
    | F.expr("exists(measurements, x -> x IS NULL)")
)

invalid_df = silver_df.filter(invalid_condition)
valid_df = silver_df.filter(~invalid_condition)

print("Parsed records:", silver_df.count())
print("Valid records:", valid_df.count())
print("Invalid records:", invalid_df.count())

# Train/test class distribution
display(
    valid_df.groupBy("split_name", "class_label")
    .count()
    .orderBy("split_name", "class_label")
)

# Measurement count validation
display(
    valid_df.groupBy("split_name")
    .agg(
        F.min("measurement_count").alias("min_values"),
        F.max("measurement_count").alias("max_values"),
        F.count("*").alias("records")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC Creating a silver_table

# COMMAND ----------

from pyspark.sql import functions as F

SILVER_TABLE = "Wafer_Guard_AI.silver_wafer.wafer_timeseries_clean"

print("Silver table name:", SILVER_TABLE)

# COMMAND ----------

# MAGIC %md
# MAGIC save the Silver Delta table

# COMMAND ----------

(
    valid_df.write
    .format("delta")
    .mode("overwrite")
    .option("overwriteSchema", "true")
    .saveAsTable(SILVER_TABLE)
)

print("Silver table created:", SILVER_TABLE)
print("Silver records:", spark.table(SILVER_TABLE).count())

display(spark.table(SILVER_TABLE).limit(10))

# COMMAND ----------

# MAGIC %md
# MAGIC Final silver validation

# COMMAND ----------

silver_check = spark.table(SILVER_TABLE)

print("Final Silver row count:", silver_check.count())

# Confirm train/test separation
display(
    silver_check.groupBy("split_name")
    .count()
)

# Confirm class labels and record counts
display(
    silver_check.groupBy("split_name", "class_label")
    .count()
    .orderBy("split_name", "class_label")
)

# Check measurement count consistency
display(
    silver_check.groupBy("split_name")
    .agg(
        F.min("measurement_count").alias("min_values"),
        F.max("measurement_count").alias("max_values"),
        F.avg("measurement_count").alias("avg_values")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC Average count

# COMMAND ----------

display(
    silver_check.groupBy("split_name")
    .agg(
        F.round(
            F.avg("measurement_count"), 2
        ).alias("avg_measurement_count")
    )
)

# COMMAND ----------

# MAGIC %md
# MAGIC check columns and data types

# COMMAND ----------

SILVER_TABLE = "Wafer_Guard_AI.silver_wafer.wafer_timeseries_clean"

silver_df = spark.table(SILVER_TABLE)

# Print column names, data types, and nullable information
silver_df.printSchema()